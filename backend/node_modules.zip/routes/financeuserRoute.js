import express from 'express';
import { createUser, getAllUsers } from '../controller/financeController.js';
import authMiddleware from '../middleware/authMiddleware.js';

const financeuserRouter = express.Router();

financeuserRouter.get("/get", getAllUsers);
financeuserRouter.post("/create", createUser);

export default financeuserRouter;